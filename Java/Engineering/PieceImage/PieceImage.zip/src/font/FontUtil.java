package font;

public class FontUtil {

	
	public static void loadFont()
	{
		
	}
	
}
